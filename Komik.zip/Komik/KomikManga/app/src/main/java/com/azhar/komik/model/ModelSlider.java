package com.azhar.komik.model;

/**
 * Created by Azhar Rivaldi on 22-12-2019.
 */
public class ModelSlider {

    private String thumb;

    public String getThumb() {
        return thumb;
    }

    public void setThumb(String thumb) {
        this.thumb = thumb;
    }
}
